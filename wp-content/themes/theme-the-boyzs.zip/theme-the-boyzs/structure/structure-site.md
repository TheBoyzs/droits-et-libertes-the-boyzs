# Accueil
## TYPE DE CONTENU (POST TYPE)
### page

## MODÈLE (TEMPLATE)
### home.php

## AUTRES CHAMPS PERSONNALISÉS (CUSTOM FIELDS) SANS LIEN AVEC UNE COMPOSANTE
### testimony: text-area




# À propos
## TYPE DE CONTENU (POST TYPE)
### page

## MODÈLE (TEMPLATE)
### about.php
## COMPOSANTE DE LA PAGES
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
#### hero
### CHAMPS PERSONNALISÉS
##### title: text
### CHAMPS PERSONNALISÉS
##### description: text-area








# Equipe
## TYPE DE CONTENU (POST TYPE)
### page

## MODÈLE (TEMPLATE)
### teams.php
## COMPOSANTE DE LA PAGES
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
#### hero
### CHAMPS PERSONNALISÉS
##### title: text
### CHAMPS PERSONNALISÉS
##### description: text-area



# Nouvelle
## TYPE DE CONTENU (POST TYPE)
### page

## MODÈLE (TEMPLATE)
### news.php
## COMPOSANTE DE LA PAGES
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
#### hero
### CHAMPS PERSONNALISÉS
##### title: text
### CHAMPS PERSONNALISÉS
##### description: text-area



# Liste de nouvelle
## TYPE DE CONTENU (POST TYPE)
### page

## MODÈLE (TEMPLATE)
### newslist.php
## COMPOSANTE DE LA PAGES
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
#### hero
### CHAMPS PERSONNALISÉS
##### title: text
### CHAMPS PERSONNALISÉS
##### description: text-area


# Luttes
## TYPE DE CONTENU (POST TYPE)
### page

## MODÈLE (TEMPLATE)
### fights.php
## COMPOSANTE DE LA PAGES
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
#### hero
### CHAMPS PERSONNALISÉS
##### title: text
### CHAMPS PERSONNALISÉS
##### description: text-area

# Liste de luttes
## TYPE DE CONTENU (POST TYPE)
### page

## MODÈLE (TEMPLATE)
### fightslist.php
## COMPOSANTE DE LA PAGES
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
#### hero
### CHAMPS PERSONNALISÉS
##### title: text
### CHAMPS PERSONNALISÉS
##### description: text-area

# Contact
## TYPE DE CONTENU (POST TYPE)
### page

## MODÈLE (TEMPLATE)
### contact.php
## COMPOSANTE DE LA PAGES
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
#### hero
### CHAMPS PERSONNALISÉS
##### title: text
### CHAMPS PERSONNALISÉS
##### description: text-area

# Erreur 404
## TYPE DE CONTENU (POST TYPE)
### page

## MODÈLE (TEMPLATE)
### error.php

